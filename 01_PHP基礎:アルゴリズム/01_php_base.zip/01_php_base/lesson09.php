﻿<?php
// 引数として数値を渡すと+1して返す関数を作り、
// 返り値を出力してください。

function plus($num) {
  return $num = $num + 1;
}
$num = 0;
echo plus($num); //1