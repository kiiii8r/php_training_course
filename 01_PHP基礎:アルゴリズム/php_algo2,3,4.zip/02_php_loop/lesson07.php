﻿<?php

for ($i = 0; $i < 3; $i++){
  $num = 1;
  for ($j = 0 + $i; $j < 3; $j++){
    echo $num;
    $num++;
  }
  echo '<br>'; 
}

// 以下をfor文を使用して表示してください。

// 123
// 12
// 1