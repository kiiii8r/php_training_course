﻿<?php

$num = 9;

for ($i = 0; $i < 3; $i++){
  for ($j = 0; $j < 3; $j++){
      echo $num;
      $num -= 1;
  }
  echo '<br>'; 
}
// 以下をfor文を使用して表示してください。

// 987
// 654
// 321