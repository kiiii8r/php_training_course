﻿<?php
// 「Hello world.」という文字列を
// 変数に代入して出力してください。

$text = 'Hello world.'; 
echo($text);