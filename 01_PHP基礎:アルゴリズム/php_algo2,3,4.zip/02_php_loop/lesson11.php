﻿<?php

for ($i = 0; $i < 3; $i++){
  $num = 3 - $i; 
  for ($j = 0 + $i; $j < 3; $j++){
    echo $num;
    $num--;
  }
  echo '<br>'; 
}

// 以下をfor文を使用して表示してください。

// 321
// 21
// 1