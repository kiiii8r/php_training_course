﻿<?php

for ($i = 1; $i <= 3; $i++){
  echo $i;
    for ($j = 1; $j < 3; $j++){
      echo $j;
    }
  echo '<br>'; 
}
// 以下をfor文を使用して表示してください。

// 112
// 212
// 312