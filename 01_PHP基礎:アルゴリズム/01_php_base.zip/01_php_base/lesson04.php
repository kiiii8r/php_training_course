﻿<?php
// 配列$colorsにred,blue,yellowを格納し、
// buleを出力してください。
$colors = ['red', 'blue', 'yellow'];

echo $colors[1];